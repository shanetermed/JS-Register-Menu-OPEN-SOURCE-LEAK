Config = {
    Color = "#005CC6",
    RGBColor = {0, 92, 198},
    Locale = 'en',
    esextendedname = "core" -- rename core to your es_extended name
}