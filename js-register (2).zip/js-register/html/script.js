const updatePrimaryColor = (color) => {
    document.documentElement.style.setProperty("--primary-color", color);
    document.documentElement.style.setProperty("--boxshadow-color", color+"40");
  };

  window.addEventListener("message", (event) => {
    if (event.data.type === "setcolor") {

      if (event.data.color) {
        updatePrimaryColor(event.data.color);
      }
    }
  });

  const registerContainer = document.querySelector(".register");
  
  window.addEventListener("message", (event) => {
    if (event.data.type === "enableui") {
        if (event.data.enable === false) {
            registerContainer.style.pointerEvents = "none"
            registerContainer.style.left = "-50%";
        } else {
            registerContainer.style.pointerEvents = "all"
            registerContainer.style.left = "0%";
        }
    }
  });

   

  const badWords = [
    "faggot", "nigger", "paki", "coon", "asshole", "bastard", "bitch",
    "bollocks", "cock", "crap", "cunt", "damn", "dick", "douche", "fuck",
    "goddamn", "hell", "homo", "jerk", "kike", "motherfucker", "nigga",
    "prick", "pussy", "shit", "slut", "spic", "twat", "wanker", "whore",
  ];

  let firstName = "";
  let lastName = "";
  let dob = "";
  let height = 175;
  let weight = 75;

  const firstNameInput = document.getElementById("firstName");
  const lastNameInput = document.getElementById("lastName");
  const dobInput = document.getElementById("dob");
  const heightSlider = document.getElementById("heightSlider");
  const weightSlider = document.getElementById("weightSlider");
  const heightValueDisplay = document.getElementById("heightValue");
  const weightValueDisplay = document.getElementById("weightValue");
  const continueButton = document.getElementById("continueBtn");

  const handleNameChange = (input, setName) => {
    input.addEventListener("input", (e) => {
      const value = e.target.value;
      const regex = /^[a-zA-Z]*$/;
  
      if (!regex.test(value)) return;
  
      const containsBadWord = badWords.some((word) =>
        value.toLowerCase().includes(word)
      );
  
      setName(value);
  
      const isValid = value.length > 2 && value.length < 25 && !containsBadWord;
  
      const parent = e.target.closest(".innerbox");
      const errorIcon = parent.querySelector(".error");
      const checkIcon = parent.querySelector(".check");
  
      if (errorIcon && checkIcon) {
        errorIcon.style.opacity = isValid ? 0 : 1; // Show error if invalid
        checkIcon.style.opacity = isValid ? 1 : 0; // Show check if valid
      }
    });
  };
  
  dobInput.addEventListener("input", (e) => {
    const cleanedValue = e.target.value.replace(/\D/g, "");
    let formattedValue = "";
  
    if (cleanedValue.length > 0) formattedValue += cleanedValue.substring(0, 2);
    if (cleanedValue.length > 2) formattedValue += "/" + cleanedValue.substring(2, 4);
    if (cleanedValue.length > 4) formattedValue += "/" + cleanedValue.substring(4, 8);
  
    dob = formattedValue;
    e.target.value = formattedValue;
  
    const regex = /^\d{2}\/\d{2}\/\d{4}$/;
    const isValidDate = regex.test(formattedValue) && (() => {
      const [day, month, year] = formattedValue.split("/").map(Number);
      return (
        month > 0 &&
        month <= 12 &&
        day > 0 &&
        day <= new Date(year, month, 0).getDate() &&
        year > 1900 &&
        year <= new Date().getFullYear() - 18
      );
    })();
  
    const parent = e.target.closest(".innerbox");
    const errorIcon = parent.querySelector(".error");
    const checkIcon = parent.querySelector(".check");
  
    if (errorIcon && checkIcon) {
      errorIcon.style.opacity = isValidDate ? 0 : 1; // Show error if invalid
      checkIcon.style.opacity = isValidDate ? 1 : 0; // Show check if valid
    }
  });

  handleNameChange(firstNameInput, (value) => (firstName = value));
  handleNameChange(lastNameInput, (value) => (lastName = value));

  const updateSlider = (slider, display, setValue, min, max) => {
    slider.addEventListener("input", () => {
      const value = slider.value;
      setValue(value);
      display.textContent = `${value} ${slider.id === "heightSlider" ? "cm" : "kg"}`;
      
      const percentage = ((value - min) / (max - min)) * 100;

      slider.style.background = `linear-gradient(to right, var(--primary-color) ${percentage}%, gray ${percentage}%)`;
    });
  };

  updateSlider(heightSlider, heightValueDisplay, (value) => (height = value), 100, 250);
  updateSlider(weightSlider, weightValueDisplay, (value) => (weight = value), 50, 100);

  document.querySelectorAll(".gender").forEach((button) => {
    button.addEventListener("click", () => {
      document.querySelectorAll(".gender").forEach((btn) => {
        btn.style.color = "";
        btn.style.border = "";
        btn.style.boxShadow = "";
      });
      button.style.color = `var(--primary-color)`;
      button.style.border = `0.5px solid var(--primary-color)`;
      button.style.boxShadow = `0px 0px 20px 0px var(--boxshadow-color)`;
    });
  });

  continueButton.addEventListener("click", async () => {
    const selectedGender = Array.from(document.querySelectorAll(".gender"))
      .find((btn) => btn.style.color === `var(--primary-color)`)?.textContent;

    const formData = {
      firstname: firstName,
      lastname: lastName,
      dateofbirth: dob,
      sex: selectedGender,
      height: height,
      weight: weight,
    };

    try {
      const response = await fetch(`https://${GetParentResourceName()}/register`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        const data = await response.json();
      } else {
      }
    } catch (error) {
    }
  });