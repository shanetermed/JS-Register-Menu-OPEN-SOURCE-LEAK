fx_version 'cerulean'
game 'gta5'
author '.j4ckst3r.'
lua54 'yes'
this_is_a_map 'yes'

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/*.lua'
}

client_scripts {
    'client/*.lua',
}

shared_scripts {
    'config.lua',
    '@ox_lib/init.lua',
    '@core/locale.lua', -- rename core to whatever your es_extended is
    '@core/imports.lua' -- rename core to whatever your es_extended is
}

ui_page 'html/index.html'

files {
  'html/index.html',
  'html/*',
  'html/imgs/*.png',
  'html/imgs/guns/*.png',
  'html/fonts/*.ttf',
}

dependencies {
  'ox_lib',
  'core', -- rename core to whatever your es_extended is
  'oxmysql'
}

escrow_ignore {
    "config.lua"
}